echo "Processing data "
#!/bin/bash
`rm -f thirdpart`
`touch thirdpart`

echo "Non-preemptive default NachOS scheduling" >> thirdpart
./nachos -F ./batch/Batch5_1.txt |grep "Average Wait" >> thirdpart

echo "Non-preemptive SJF">> thirdpart

./nachos -F ./batch/Batch5_2.txt |grep "Average Wait" >> thirdpart
