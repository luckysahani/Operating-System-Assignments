echo "Processing data "
#!/bin/bash
`rm -f fourthpart`
`touch fourthpart`

echo "Batch 1" >> fourthpart
./nachos -F ./batch/Batch1_2.txt |grep "Error in " >> fourthpart

echo "Batch 2">> fourthpart

./nachos -F ./batch/Batch2_2.txt |grep "Error in " >> fourthpart

echo "Batch 3">> fourthpart

./nachos -F ./batch/Batch3_2.txt |grep "Error in " >> fourthpart


echo "Batch 4">> fourthpart

./nachos -F ./batch/Batch4_2.txt |grep "Error in " >> fourthpart


echo "Batch 5">> fourthpart

./nachos -F ./batch/Batch5_2.txt |grep "Error in " >> fourthpart

