echo "Processing data "
#!/bin/bash
`rm -f fifthpart`
`touch fifthpart`

echo "Batch 6" >> fifthpart

echo "Round Robin" >> fifthpart

./nachos -F ./batch/Batch6_1.txt |grep "Completion time statistics" >> fifthpart



echo "Unix" >> fifthpart

./nachos -F ./batch/Batch6_2.txt |grep "Completion time statistics" >> fifthpart
