#!/bin/bash
touch Batch1_2.txt
touch Batch1_3.txt
touch Batch1_4.txt
touch Batch1_5.txt
touch Batch1_6.txt
touch Batch1_7.txt
touch Batch1_8.txt
touch Batch1_9.txt
touch Batch1_10.txt


touch Batch2_2.txt
touch Batch2_3.txt
touch Batch2_4.txt
touch Batch2_5.txt
touch Batch2_6.txt
touch Batch2_7.txt
touch Batch2_8.txt
touch Batch2_9.txt
touch Batch2_10.txt

touch Batch3_2.txt
touch Batch3_3.txt
touch Batch3_4.txt
touch Batch3_5.txt
touch Batch3_6.txt
touch Batch3_7.txt
touch Batch3_8.txt
touch Batch3_9.txt
touch Batch3_10.txt

touch Batch4_2.txt
touch Batch4_3.txt
touch Batch4_4.txt
touch Batch4_5.txt
touch Batch4_6.txt
touch Batch4_7.txt
touch Batch4_8.txt
touch Batch4_9.txt
touch Batch4_10.txt