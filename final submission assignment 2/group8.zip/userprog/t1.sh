echo "Processing data "
#!/bin/bash
`rm -f firstpart`
`touch firstpart`

echo "Non-preemptive default NachOS scheduling" 
./nachos -F ./batch/Batch1_1.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch2_1.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch3_1.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch4_1.txt |grep "CPU utiliz" >> firstpart

echo "Non-preemptive default NachOS scheduling"
echo "Non-preemptive default NachOS scheduling">> firstpart

./nachos -F ./batch/Batch1_2.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch2_2.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch3_2.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch4_2.txt |grep "CPU utiliz" >> firstpart

echo "Round-robin "


./nachos -F ./batch/Batch1_3.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch2_3.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch3_3.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch4_3.txt |grep "CPU utiliz" >> firstpart

echo "Round-robin "

./nachos -F ./batch/Batch1_4.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch2_4.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch3_4.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch4_4.txt |grep "CPU utiliz" >> firstpart

echo "Round-robin "

./nachos -F ./batch/Batch1_5.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch2_5.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch3_5.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch4_5.txt |grep "CPU utiliz" >> firstpart

echo "Round-robin "

./nachos -F ./batch/Batch1_6.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch2_6.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch3_6.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch4_6.txt |grep "CPU utiliz" >> firstpart

echo "UNIX scheduler "

./nachos -F ./batch/Batch1_7.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch2_7.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch3_7.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch4_7.txt |grep "CPU utiliz" >> firstpart

echo "UNIX scheduler "

./nachos -F ./batch/Batch1_8.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch2_8.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch3_8.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch4_8.txt |grep "CPU utiliz" >> firstpart

echo " UNIX scheduler"

./nachos -F ./batch/Batch1_9.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch2_9.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch3_9.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch4_9.txt |grep "CPU utiliz" >> firstpart

echo " UNIX scheduler"

./nachos -F ./batch/Batch1_10.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch2_10.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch3_10.txt |grep "CPU utiliz" >> firstpart
./nachos -F ./batch/Batch4_10.txt |grep "CPU utiliz" >> firstpart

